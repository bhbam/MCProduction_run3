#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

"""
WMCore wrappers.
"""
