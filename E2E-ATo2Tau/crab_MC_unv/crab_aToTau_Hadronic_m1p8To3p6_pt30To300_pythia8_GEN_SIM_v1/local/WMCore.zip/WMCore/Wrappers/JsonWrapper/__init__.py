#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-

"""
We used to have a wrapper here to wrap different JSON implementations. No longer needed with python 2.7
"""

