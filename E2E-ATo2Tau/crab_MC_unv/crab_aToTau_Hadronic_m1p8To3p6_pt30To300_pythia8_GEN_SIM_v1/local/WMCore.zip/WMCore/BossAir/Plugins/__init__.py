#!/usr/bin/env python
"""
_BossAir.Plugins_

Plugins for the BossAir library

"""
__all__ = []
