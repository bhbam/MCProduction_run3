#!/usr/bin/env python
"""
_Credential_

"""

__all__ = []
