#!/usr/bin/env python
"""
_WMCore.WMSpec_

"""



__all__ = []
