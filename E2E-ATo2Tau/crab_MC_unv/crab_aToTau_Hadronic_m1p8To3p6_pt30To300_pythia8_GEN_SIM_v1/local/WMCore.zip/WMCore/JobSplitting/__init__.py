#!/usr/bin/env python
"""
_JobSplitting_

A set of algorithms to allocate work to a set of jobs split along lines
like event, run, lumi, file.

"""
__all__ = []
