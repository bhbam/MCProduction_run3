#!/usr/bin/env python
"""
_WMCore_

Core libraries for Workload Management Packages

"""

__version__ = '2.3.6rc2'
__all__ = []
